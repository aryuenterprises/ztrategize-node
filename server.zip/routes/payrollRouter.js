

import express from 'express';
// import payroll from '../controllers/payroll.js';

const payrollRouter = express.Router();

// payrollRouter.post("/calculate-salary",payroll);

export default payrollRouter;    